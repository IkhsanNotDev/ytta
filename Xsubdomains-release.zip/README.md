# Xsubdomains

Lightweight Blueprint extension for Pterodactyl that lets users create Minecraft-ready subdomains for server allocations.

## Requirements

- Pterodactyl Panel
- Blueprint Framework
- Cloudflare-managed domain
- Cloudflare API token with Zone DNS edit access

## Install

1. Upload `Xsubdomains.blueprint` to `/var/www/pterodactyl`.
2. Run:

```bash
cd /var/www/pterodactyl
blueprint -install Xsubdomains.blueprint
```

3. Open the Pterodactyl admin panel.
4. Go to Blueprint extensions, open Xsubdomains, and save your Cloudflare access details.
5. Add each Cloudflare domain you want users to create subdomains under.

## Cloudflare Token

Create an API token with:

- Zone: DNS: Edit
- Zone: Zone: Read

Limit the token to the zones you plan to use.

## User Flow

Users open a server, select the Subdomain tab, choose an available allocation, and create a clean connection address. The extension creates matching Cloudflare DNS records and removes them when the subdomain is deleted.

## Uninstall

```bash
cd /var/www/pterodactyl
blueprint -remove xsubdomains
```

## Changelog

### 0.5.0

- Renamed release to Xsubdomains.
- Refreshed panel copy.
- Added safer allocation ownership validation.
- Scoped duplicate subdomain checks per domain.
- Added database uniqueness constraints.
- Removed debug console output from the frontend.
- Improved Cloudflare error handling.

## Standalone

Use `Xsubdomains-standalone.zip` for non-Blueprint panels. The standalone package patches the standard Pterodactyl route files directly and uses `.env` for Cloudflare access.

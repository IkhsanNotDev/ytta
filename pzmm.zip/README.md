#  ______ ______ __  __ __  __ 
# |  __ \|___  /|  \/  |  \/  |
# | |__) |  / / | \  / | \  / |
# |  ___/  / /  | |\/| | |\/| |
# | |     / /__ | |  | | |  | |
# |_|    /_____||_|  |_|_|  |_|  v1.x


🔹 Thank you for downloading PZMM! 
No more digging through `.ini` files or wrestling with Workshop IDs and files by hand.

🔹 Extension installation.
Before you can start using PZMM, you'll need Blueprint. Blueprint is what makes extensions like this play nicely with everything else on your panel.  
You can find more information, download links and documentation at **https://blueprint.zip**.

After you've installed Blueprint, drag and drop the `pzmm.blueprint` file over to your Pterodactyl folder (commonly `/var/www/pterodactyl`) and run:

```bash
blueprint -install pzmm